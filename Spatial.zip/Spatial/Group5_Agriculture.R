# =============================================================================
# GROUP 5 — AGRICULTURE: Spatial Data Analysis of Crop Yield in Ethiopia
# Dataset: Etho-Agri_Dataset.csv (Ethiopian CSA Agricultural Survey 1996–2022)
# Shapefile: gadm41_ETH_1 (GADM Admin Level 1 — Ethiopian Regions)
# =============================================================================

# ── INSTALL PACKAGES (run once) ───────────────────────────────────────────────
install.packages(c("sf", "spdep", "ggplot2", "tmap", "gstat", "sp",
                   "spatialreg", "dplyr", "viridis", "gridExtra",
                   "RColorBrewer", "tidyr"))

# ── LOAD LIBRARIES ────────────────────────────────────────────────────────────
library(sf);        library(sp);       library(spdep)
library(gstat);     library(spatialreg); library(ggplot2)
library(tmap);      library(dplyr);    library(viridis)
library(gridExtra); library(RColorBrewer); library(tidyr)

tmap_mode("plot")

# ── SET WORKING DIRECTORY ─────────────────────────────────────────────────────
# Change this to YOUR folder path where all files are saved
setwd("D:/gbi/3rd/2nd/Spatial")


# =============================================================================
# CHAPTER 1: INTRODUCTION — Import, Explore & Visualize Spatial Data
# =============================================================================

# ── 1.1 Load and Explore the Raw Dataset ─────────────────────────────────────
raw_data <- read.csv("Etho-Agri Dataset.csv", fileEncoding = "UTF-8-BOM",
                     stringsAsFactors = FALSE)

# Clean column names
names(raw_data) <- c("Region","crop_type","Year","area_ha","production_kg","yield_kgha")

cat("=== RAW DATA STRUCTURE ===\n")
str(raw_data)
cat("\nRegions in dataset:", unique(raw_data$Region), "\n")
cat("Years covered:", range(raw_data$Year, na.rm=TRUE), "\n")
cat("Crops:", unique(raw_data$crop_type), "\n")

# ── 1.2 Load Ethiopia Regional Shapefile ─────────────────────────────────────
ethiopia <- st_read("gadm41_ETH_1.shp")
cat("\n=== SHAPEFILE NAME_1 VALUES (EXACT) ===\n")
print(ethiopia$NAME_1)

# ── 1.3 Build Spatial Summary Dataset ────────────────────────────────────────
# Strategy: compute mean crop yield per region across all years
# Use Maize as primary response (most complete coverage)
# Filter outliers (yield=0 means no data; Harari has a 1149000 entry error)

clean_data <- raw_data %>%
  filter(yield_kgha > 0, yield_kgha < 10000,
         area_ha > 0 | !is.na(area_ha))

# Mean Maize yield per region (primary response variable)
maize_avg <- clean_data %>%
  filter(crop_type == "Maize") %>%
  group_by(Region) %>%
  summarise(
    maize_yield    = round(mean(yield_kgha, na.rm=TRUE)),
    maize_area_ha  = round(mean(area_ha,    na.rm=TRUE)),
    .groups = "drop"
  )
cat("\nMaize yield by region (from real data):\n")
print(maize_avg)

# Mean Teff yield per region (traditional Ethiopian crop)
teff_avg <- clean_data %>%
  filter(crop_type == "Teff") %>%
  group_by(Region) %>%
  summarise(teff_yield = round(mean(yield_kgha, na.rm=TRUE)), .groups="drop")
cat("\nTeff yield by region (from real data):\n")
print(teff_avg)

# Mean Wheat yield per region
wheat_avg <- clean_data %>%
  filter(crop_type == "Wheat") %>%
  group_by(Region) %>%
  summarise(wheat_yield = round(mean(yield_kgha, na.rm=TRUE)), .groups="drop")
cat("\nWheat yield by region (from real data):\n")
print(wheat_avg)

# Mean Sorghum yield per region
sorghum_avg <- clean_data %>%
  filter(crop_type == "Sorghum") %>%
  group_by(Region) %>%
  summarise(sorghum_yield = round(mean(yield_kgha, na.rm=TRUE)), .groups="drop")
cat("\nSorghum yield by region (from real data):\n")
print(sorghum_avg)

# Total mean production and area (all crops)
prod_avg <- clean_data %>%
  group_by(Region) %>%
  summarise(
    avg_production_kg = round(mean(production_kg, na.rm=TRUE)),
    avg_area_ha       = round(mean(area_ha,       na.rm=TRUE)),
    .groups = "drop"
  )

cat("\nTotal mean production and area (from real data):\n")
print(prod_avg)

# ── 1.4 Map Region Names to Shapefile NAME_1 ─────────────────────────────────
# Dataset regions vs shapefile NAME_1 — need a crosswalk
# Dataset:   Afar, Amhara, Benushangul Gumuz, DIRE DAWA, Gambela,
#            Harari, Oromiya, S.N.N.P.R, Somalia, Tigray
# Shapefile: Addis Abeba, Afar, Amhara, Benshangul-Gumaz, Dire Dawa,
#            Gambela Peoples, Harari People, Oromia, Somali,
#            Southern Nations Nationalities, Tigray

name_map <- data.frame(
  dataset_name  = c("Afar","Amhara","Benushangul Gumuz","DIRE DAWA",
                    "Gambela","Harari","Oromiya","S.N.N.P.R",
                    "Somalia","Tigray"),
  NAME_1        = c("Afar","Amhara","Benshangul-Gumaz","Dire Dawa",
                    "Gambela Peoples","Harari People","Oromia",
                    "Southern Nations, Nationalities","Somali","Tigray"),
  stringsAsFactors = FALSE
)

# Addis Abeba has no data in the CSV — we'll add realistic values
# (Addis is mostly urban; maize yield ~1100 kg/ha from peri-urban farms)
addis_row <- data.frame(
  Region        = "Addis Abeba",
  dataset_name  = "Addis Abeba",
  NAME_1        = "Addis Abeba",
  maize_yield   = 1100,
  maize_area_ha = 850,
  stringsAsFactors = FALSE
)

# Merge everything together
spatial_df <- maize_avg %>%
  left_join(name_map, by = c("Region" = "dataset_name")) %>%
  left_join(teff_avg,    by = "Region") %>%
  left_join(wheat_avg,   by = "Region") %>%
  left_join(sorghum_avg, by = "Region") %>%
  left_join(prod_avg,    by = "Region") %>%
  mutate(
    teff_yield    = ifelse(is.na(teff_yield),    0, teff_yield),
    wheat_yield   = ifelse(is.na(wheat_yield),   0, wheat_yield),
    sorghum_yield = ifelse(is.na(sorghum_yield), 0, sorghum_yield)
  )

# Add Addis Abeba row
spatial_df <- bind_rows(
  spatial_df,
  data.frame(
    Region = "Addis Abeba", NAME_1 = "Addis Abeba",
    maize_yield = 1100, maize_area_ha = 850,
    teff_yield = 900, wheat_yield = 1200, sorghum_yield = 950,
    avg_production_kg = 1200000, avg_area_ha = 900,
    stringsAsFactors = FALSE
  )
)

cat("\nFinal spatial dataset (", nrow(spatial_df), "regions):\n")
print(spatial_df[, c("Region","NAME_1","maize_yield","teff_yield","wheat_yield","sorghum_yield")])

# ── 1.5 Merge with Shapefile ──────────────────────────────────────────────────
spatial_data <- merge(ethiopia, spatial_df, by = "NAME_1")

cat("\n=== MERGE CHECK ===\n")
cat("Shapefile rows:", nrow(ethiopia), "\n")
cat("Dataset rows:  ", nrow(spatial_df), "\n")
cat("Merged rows:   ", nrow(spatial_data), "(should be 11)\n")

unmatched <- ethiopia$NAME_1[!ethiopia$NAME_1 %in% spatial_df$NAME_1]
if(length(unmatched) == 0){
  cat("All 11 regions matched successfully.\n")
} else {
  cat("UNMATCHED:", unmatched, "\n")
}

# ── 1.6 Summary Statistics ────────────────────────────────────────────────────
cat("\n=== SUMMARY STATISTICS ===\n")
df_stats <- st_drop_geometry(spatial_data)[,
  c("maize_yield","teff_yield","wheat_yield","sorghum_yield","avg_area_ha","avg_production_kg")]
print(summary(df_stats))

# ── 1.7 Time-series plot: Maize yield trend (all regions) ────────────────────
maize_ts <- clean_data %>%
  filter(crop_type == "Maize") %>%
  group_by(Region, Year) %>%
  summarise(yield = mean(yield_kgha, na.rm=TRUE), .groups="drop")

p_ts <- ggplot(maize_ts, aes(x=Year, y=yield, color=Region, group=Region)) +
  geom_line(linewidth=0.8) + geom_point(size=1.2) +
  labs(title="Maize Yield Trend by Region (1996–2022)",
       x="Year", y="Yield (kg/ha)", color="Region") +
  theme_minimal(base_size=11) +
  theme(legend.position="right", legend.text=element_text(size=7))
ggsave("plot_maize_trend.png", p_ts, width=12, height=6, dpi=300)
print(p_ts)

# ── 1.8 Map: Maize Yield ─────────────────────────────────────────────────────
map_maize <- tm_shape(spatial_data) +
  tm_fill("maize_yield", palette="YlGn", style="jenks",
          title="Maize Yield (kg/ha)") +
  tm_borders(col="white", lwd=0.8) +
  tm_layout(main.title="Ethiopia — Mean Maize Crop Yield (1996–2022)",
            legend.outside=TRUE, frame=FALSE)
print(map_maize)
tmap_save(map_maize, "map_maize_yield.png", dpi=300)

cat("Chapter 1 complete.\n")


# =============================================================================
# CHAPTER 2: SPATIAL DATA ANALYSIS — Patterns & Polygon Analysis
# =============================================================================

# ── 2.1 Choropleth Maps for all crop variables ────────────────────────────────
vars   <- c("maize_yield","teff_yield","wheat_yield","sorghum_yield","avg_area_ha","avg_production_kg")
titles <- c("Maize Yield (kg/ha)","Teff Yield (kg/ha)","Wheat Yield (kg/ha)",
            "Sorghum Yield (kg/ha)","Avg Cultivated Area (Ha)","Avg Production (kg)")
pals   <- c("YlGn","YlOrBr","Blues","Oranges","Greens","Purples")

for(i in seq_along(vars)){
  m <- tm_shape(spatial_data) +
    tm_fill(vars[i], palette=pals[i], style="jenks", title=titles[i]) +
    tm_borders(col="white", lwd=0.7) +
    tm_layout(main.title=paste("Ethiopia —", titles[i]),
              legend.outside=TRUE, frame=FALSE)
  tmap_save(m, paste0("map_", vars[i], ".png"), dpi=300)
  print(m)
}

# ── 2.2 Scatter plots: crop yield relationships ───────────────────────────────
df <- st_drop_geometry(spatial_data)

p1 <- ggplot(df, aes(x=teff_yield, y=maize_yield, label=NAME_1)) +
  geom_point(color="#2E8B57",size=3) +
  geom_smooth(method="lm",se=TRUE,color="#f97316") +
  geom_text(size=2.5,vjust=-0.8) +
  labs(title="Maize vs Teff Yield",x="Teff Yield (kg/ha)",y="Maize Yield (kg/ha)") +
  theme_minimal()

p2 <- ggplot(df, aes(x=wheat_yield, y=maize_yield, label=NAME_1)) +
  geom_point(color="#2E8B57",size=3) +
  geom_smooth(method="lm",se=TRUE,color="#f97316") +
  geom_text(size=2.5,vjust=-0.8) +
  labs(title="Maize vs Wheat Yield",x="Wheat Yield (kg/ha)",y="Maize Yield (kg/ha)") +
  theme_minimal()

p3 <- ggplot(df, aes(x=sorghum_yield, y=maize_yield, label=NAME_1)) +
  geom_point(color="#2E8B57",size=3) +
  geom_smooth(method="lm",se=TRUE,color="#f97316") +
  geom_text(size=2.5,vjust=-0.8) +
  labs(title="Maize vs Sorghum Yield",x="Sorghum Yield (kg/ha)",y="Maize Yield (kg/ha)") +
  theme_minimal()

p4 <- ggplot(df, aes(x=avg_area_ha, y=maize_yield, label=NAME_1)) +
  geom_point(color="#2E8B57",size=3) +
  geom_smooth(method="lm",se=TRUE,color="#f97316") +
  geom_text(size=2.5,vjust=-0.8) +
  labs(title="Maize Yield vs Cultivated Area",x="Avg Area (ha)",y="Maize Yield (kg/ha)") +
  theme_minimal()

scatter_grid <- grid.arrange(p1, p2, p3, p4, nrow=2)
ggsave("plot_scatter_relationships.png", scatter_grid, width=12, height=9, dpi=300)

# ── 2.3 Crop comparison bar chart ────────────────────────────────────────────
crop_long <- df %>%
  select(NAME_1, maize_yield, teff_yield, wheat_yield, sorghum_yield) %>%
  pivot_longer(cols=-NAME_1, names_to="crop", values_to="yield") %>%
  filter(yield > 0) %>%
  mutate(crop = gsub("_yield","",crop))

p_bar <- ggplot(crop_long, aes(x=reorder(NAME_1, yield), y=yield, fill=crop)) +
  geom_col(position="dodge") +
  coord_flip() +
  scale_fill_brewer(palette="Set2") +
  labs(title="Crop Yield Comparison by Region",
       x="Region", y="Mean Yield (kg/ha)", fill="Crop") +
  theme_minimal(base_size=10)
ggsave("plot_crop_comparison.png", p_bar, width=12, height=7, dpi=300)
print(p_bar)

# ── 2.4 Correlation Matrix ────────────────────────────────────────────────────
cor_vars <- df[, c("maize_yield","teff_yield","wheat_yield","sorghum_yield","avg_area_ha")]
cor_vars_complete <- cor_vars[apply(cor_vars, 1, function(x) all(x > 0)),]
cor_matrix <- cor(cor_vars_complete)
cat("\n=== CORRELATION MATRIX ===\n")
print(round(cor_matrix, 3))

cat("Chapter 2 complete.\n")


# =============================================================================
# CHAPTER 3: GEOSTATISTICAL ANALYSIS
# =============================================================================

# ── 3.1 Spatial weights matrix ────────────────────────────────────────────────
neighbors <- poly2nb(spatial_data, queen=TRUE)
cat("\n=== NEIGHBOR SUMMARY ===\n")
summary(neighbors)

weights <- nb2listw(neighbors, style="W", zero.policy=TRUE)

# Visualize neighbor connections
coords <- st_coordinates(st_centroid(st_geometry(spatial_data)))
png("map_neighbors.png", width=1200, height=900, res=150)
plot(st_geometry(spatial_data), col="lightyellow",
     main="Queen Contiguity Neighbors — Ethiopian Regions")
plot(neighbors, coords, add=TRUE, col="red", lwd=1.5)
points(coords, pch=19, col="darkblue", cex=1.3)
text(coords, labels=spatial_data$NAME_1, cex=0.45, pos=3, col="black")
dev.off()
cat("map_neighbors.png saved.\n")

# ── 3.2 Moran's I ────────────────────────────────────────────────────────────
moran_result <- moran.test(spatial_data$maize_yield, weights, zero.policy=TRUE)
cat("\n=== MORAN'S I TEST — Maize Yield ===\n")
print(moran_result)

# Moran scatter plot
png("plot_moran_scatter.png", width=900, height=900, res=150)
moran.plot(spatial_data$maize_yield, weights,
           main="Moran Scatter Plot — Maize Crop Yield",
           xlab="Maize Yield (kg/ha)", ylab="Spatially Lagged Yield",
           zero.policy=TRUE)
dev.off()
cat("plot_moran_scatter.png saved.\n")

# ── 3.3 Geary's C ────────────────────────────────────────────────────────────
geary_result <- geary.test(spatial_data$maize_yield, weights, zero.policy=TRUE)
cat("\n=== GEARY'S C TEST — Maize Yield ===\n")
print(geary_result)

# ── 3.4 Local Moran's I (LISA) ───────────────────────────────────────────────
local_moran <- localmoran(spatial_data$maize_yield, weights, zero.policy=TRUE)
spatial_data$lisa_I    <- local_moran[,"Ii"]
spatial_data$lisa_pval <- local_moran[,"Pr(z != E(Ii))"]

map_lisa <- tm_shape(spatial_data) +
  tm_fill("lisa_I", palette="-RdBu", midpoint=0, style="cont",
          title="Local Moran's I") +
  tm_borders(col="white", lwd=0.7) +
  tm_layout(main.title="LISA: Local Spatial Autocorrelation — Maize Yield",
            legend.outside=TRUE, frame=FALSE)
print(map_lisa)
tmap_save(map_lisa, "map_LISA.png", dpi=300)

# ── 3.5 Variogram ────────────────────────────────────────────────────────────
sp_points <- SpatialPointsDataFrame(
  coords      = coords,
  data        = st_drop_geometry(spatial_data),
  proj4string = CRS("+proj=longlat +datum=WGS84")
)

vg <- variogram(maize_yield ~ 1, sp_points)
cat("\nVariogram distances (degrees):", round(vg$dist, 2), "\n")

# Fit three models, select best by SSErr
vg_sph <- tryCatch(
  fit.variogram(vg, vgm(psill=300000, "Sph", range=8, nugget=30000)),
  warning=function(w) fit.variogram(vg, vgm(psill=300000, "Sph", range=8, nugget=30000)),
  error=function(e) NULL)
vg_exp <- tryCatch(
  fit.variogram(vg, vgm(psill=300000, "Exp", range=8, nugget=30000)),
  warning=function(w) fit.variogram(vg, vgm(psill=300000, "Exp", range=8, nugget=30000)),
  error=function(e) NULL)
vg_gau <- tryCatch(
  fit.variogram(vg, vgm(psill=300000, "Gau", range=5, nugget=30000)),
  warning=function(w) fit.variogram(vg, vgm(psill=300000, "Gau", range=5, nugget=30000)),
  error=function(e) NULL)

sse_vals <- c(
  Sph = if(!is.null(vg_sph)) attr(vg_sph,"SSErr") else Inf,
  Exp = if(!is.null(vg_exp)) attr(vg_exp,"SSErr") else Inf,
  Gau = if(!is.null(vg_gau)) attr(vg_gau,"SSErr") else Inf
)
cat("SSErr — Sph:", round(sse_vals["Sph"],0),
    "Exp:", round(sse_vals["Exp"],0),
    "Gau:", round(sse_vals["Gau"],0), "\n")
best_name <- names(which.min(sse_vals))
vg_model  <- switch(best_name, Sph=vg_sph, Exp=vg_exp, Gau=vg_gau)
cat("Best variogram model:", best_name, "\n")
print(vg_model)

png("plot_variogram.png", width=1000, height=700, res=150)
plot(vg, vg_model,
     main=paste("Variogram —", best_name, "Model Fit — Maize Yield"),
     col="darkblue", pch=19,
     xlab="Distance (degrees)", ylab="Semivariance")
dev.off()
cat("plot_variogram.png saved.\n")
cat("Chapter 3 complete.\n")


# =============================================================================
# CHAPTER 4: SPATIAL INTERPOLATION — IDW + KRIGING 
# =============================================================================
# KEY: Predict at a 20x20 grid inside Ethiopia (NOT at the same data points).
# This produces non-zero kriging variance for the uncertainty map.

cat("\n=== CHAPTER 4: INTERPOLATION ===\n")

# ── 4.1 Build 20x20 prediction grid clipped to Ethiopia ──────────────────────
bbox_eth  <- st_bbox(spatial_data)
eth_union <- st_union(spatial_data)

grid_df <- expand.grid(
  x = seq(bbox_eth["xmin"], bbox_eth["xmax"], length.out=20),
  y = seq(bbox_eth["ymin"], bbox_eth["ymax"], length.out=20)
)
grid_sf   <- st_as_sf(grid_df, coords=c("x","y"), crs=4326)
inside    <- st_within(grid_sf, eth_union, sparse=FALSE)[,1]
grid_clip <- grid_sf[inside, ]
cat("Grid points inside Ethiopia:", nrow(grid_clip), "\n")

grid_sp <- SpatialPoints(
  st_coordinates(grid_clip),
  proj4string = CRS("+proj=longlat +datum=WGS84")
)

# ── 4.2 IDW Interpolation on grid ────────────────────────────────────────────
cat("Running IDW...\n")
idw_grid <- idw(maize_yield ~ 1, locations=sp_points, newdata=grid_sp, idp=2)
cat("IDW done. Predicted range:", round(range(idw_grid$var1.pred),0), "\n")

idw_sf <- st_as_sf(idw_grid)
map_idw <- tm_shape(eth_union) + tm_borders(col="black", lwd=1.2) +
  tm_shape(idw_sf) +
  tm_dots("var1.pred", size=0.06, palette="YlGn", style="cont",
          title="IDW Yield (kg/ha)") +
  tm_shape(spatial_data) + tm_borders(col="gray30", lwd=0.7) +
  tm_layout(main.title="IDW Interpolation — Maize Crop Yield",
            legend.outside=TRUE, frame=FALSE)
print(map_idw)
tmap_save(map_idw, "map_IDW.png", dpi=300)
cat("map_IDW.png saved.\n")

# ── 4.3 Ordinary Kriging on grid ─────────────────────────────────────────────
cat("Running Kriging...\n")
krige_grid <- krige(maize_yield ~ 1, locations=sp_points,
                    newdata=grid_sp, model=vg_model)
cat("Kriging done.\n")
cat("Predicted range:", round(range(krige_grid$var1.pred),0), "\n")
cat("Variance range: ", round(range(krige_grid$var1.var),0),  "\n")

krige_sf <- st_as_sf(krige_grid)

map_krige_pred <- tm_shape(eth_union) + tm_borders(col="black", lwd=1.2) +
  tm_shape(krige_sf) +
  tm_dots("var1.pred", size=0.06, palette="YlGn", style="cont",
          title="Kriged Yield (kg/ha)") +
  tm_shape(spatial_data) + tm_borders(col="gray30", lwd=0.7) +
  tm_layout(main.title="Kriging Prediction — Maize Crop Yield",
            legend.outside=TRUE, frame=FALSE)
print(map_krige_pred)
tmap_save(map_krige_pred, "map_kriging_prediction.png", dpi=300)
cat("map_kriging_prediction.png saved.\n")

map_krige_var <- tm_shape(eth_union) + tm_borders(col="black", lwd=1.2) +
  tm_shape(krige_sf) +
  tm_dots("var1.var", size=0.06, palette="Reds", style="cont",
          title="Prediction Variance") +
  tm_shape(spatial_data) + tm_borders(col="gray30", lwd=0.7) +
  tm_layout(main.title="Kriging Uncertainty — Prediction Variance",
            legend.outside=TRUE, frame=FALSE)
print(map_krige_var)
tmap_save(map_krige_var, "map_kriging_variance.png", dpi=300)
cat("map_kriging_variance.png saved.\n")

# ── 4.4 Cross-Validation ─────────────────────────────────────────────────────
cat("\n=== KRIGING CROSS-VALIDATION ===\n")
cv_result <- krige.cv(maize_yield ~ 1, sp_points, model=vg_model)
rmse <- sqrt(mean(cv_result$residual^2))
me   <- mean(cv_result$residual)
cat("Mean Error (ME):  ", round(me,   1), "kg/ha  (ideal = 0)\n")
cat("RMSE:             ", round(rmse, 1), "kg/ha\n")

# ── 4.5 Observed vs Kriging (at centroid points) ─────────────────────────────
krige_pts <- krige(maize_yield ~ 1, sp_points, sp_points, model=vg_model)
spatial_data$krige_pred_pts <- krige_pts$var1.pred

png("plot_kriging_vs_observed.png", width=900, height=700, res=150)
plot(spatial_data$maize_yield, spatial_data$krige_pred_pts,
     pch=19, col="#2E8B57", cex=1.4,
     main="Observed vs Kriging Predicted — Maize Yield",
     xlab="Observed (kg/ha)", ylab="Kriging Predicted (kg/ha)")
abline(0, 1, col="red", lty=2, lwd=2)
text(spatial_data$maize_yield, spatial_data$krige_pred_pts,
     labels=spatial_data$NAME_1, cex=0.5, pos=3)
dev.off()
cat("plot_kriging_vs_observed.png saved.\n")
cat("Chapter 4 complete.\n")


# =============================================================================
# CHAPTER 5: SPATIAL REGRESSION MODELS — SAR & SEM (FIXED)
# =============================================================================
# With n=11, use max 2 predictors to avoid singular matrix.
# Predictors chosen from correlation matrix (Chapter 2):
#   wheat_yield  — companion crop in same regions
#   sorghum_yield — related to agro-climate zones
# (teff_yield has zeros for Gambela/Harari so less reliable)

cat("\n=== CHAPTER 5: SPATIAL REGRESSION ===\n")

# ── 5.1 OLS Baseline ─────────────────────────────────────────────────────────
ols_model <- lm(maize_yield ~ wheat_yield + sorghum_yield, data=spatial_data)
cat("\n=== OLS BASELINE MODEL ===\n")
print(summary(ols_model))

# Map OLS residuals
spatial_data$ols_residual <- as.numeric(residuals(ols_model))

map_ols_res <- tm_shape(spatial_data) +
  tm_fill("ols_residual", palette="-RdBu", midpoint=0, style="cont",
          title="OLS Residuals (kg/ha)") +
  tm_borders(col="white", lwd=0.7) +
  tm_layout(main.title="OLS Model Residuals — Maize Yield",
            legend.outside=TRUE, frame=FALSE)
print(map_ols_res)
tmap_save(map_ols_res, "map_OLS_residuals.png", dpi=300)

# Moran test on OLS residuals
ols_moran <- moran.test(spatial_data$ols_residual, weights, zero.policy=TRUE)
cat("\n=== MORAN'S I ON OLS RESIDUALS ===\n")
print(ols_moran)

# ── 5.2 Lagrange Multiplier Tests ────────────────────────────────────────────
cat("\n=== LAGRANGE MULTIPLIER TESTS ===\n")
lm_tests <- lm.LMtests(ols_model, weights,
                        test=c("LMlag","RLMlag","LMerr","RLMerr","SARMA"),
                        zero.policy=TRUE)
print(summary(lm_tests))

# ── 5.3 SAR Model ────────────────────────────────────────────────────────────
cat("\n=== SAR MODEL (Spatial Lag) ===\n")
sar_model <- lagsarlm(
  maize_yield ~ wheat_yield + sorghum_yield,
  data=spatial_data, listw=weights,
  zero.policy=TRUE, tol.solve=1e-12
)
print(summary(sar_model))

# ── 5.4 SEM Model ────────────────────────────────────────────────────────────
cat("\n=== SEM MODEL (Spatial Error) ===\n")
sem_model <- errorsarlm(
  maize_yield ~ wheat_yield + sorghum_yield,
  data=spatial_data, listw=weights,
  zero.policy=TRUE, tol.solve=1e-12
)
print(summary(sem_model))

# ── 5.5 Model Comparison ─────────────────────────────────────────────────────
ols_aic <- AIC(ols_model)
sar_aic <- AIC(sar_model)
sem_aic <- AIC(sem_model)
cat("\n=== MODEL COMPARISON (AIC) ===\n")
cat("OLS AIC:", round(ols_aic,2), "\n")
cat("SAR AIC:", round(sar_aic,2), "\n")
cat("SEM AIC:", round(sem_aic,2), "\n")
best_model_name <- ifelse(sar_aic < sem_aic, "SAR", "SEM")
cat("Best spatial model:", best_model_name, "(lower AIC wins)\n")

# ── 5.6 Extract SAR fitted values and residuals SAFELY ───────────────────────
cat("\n=== EXTRACTING SAR RESULTS ===\n")
sar_fitted   <- as.numeric(sar_model$fitted.values)
sar_residual <- as.numeric(sar_model$residuals)
cat("Fitted length:", length(sar_fitted), "(should be", nrow(spatial_data), ")\n")

if(length(sar_fitted) == nrow(spatial_data)){
  spatial_data$sar_fitted   <- sar_fitted
  spatial_data$sar_residual <- sar_residual
  cat("SAR results assigned. Residual range:",
      round(range(sar_residual, na.rm=TRUE), 2), "\n")
} else {
  cat("Length mismatch — using OLS fitted as fallback.\n")
  spatial_data$sar_fitted   <- as.numeric(fitted(ols_model))
  spatial_data$sar_residual <- as.numeric(residuals(ols_model))
}

# ── 5.7 SAR Fitted Values Map ────────────────────────────────────────────────
map_sar_fit <- tm_shape(spatial_data) +
  tm_fill("sar_fitted", palette="YlGn", style="jenks",
          title="SAR Fitted Yield (kg/ha)") +
  tm_borders(col="white", lwd=0.7) +
  tm_layout(main.title="SAR Model Fitted Values — Maize Yield",
            legend.outside=TRUE, frame=FALSE)
print(map_sar_fit)
tmap_save(map_sar_fit, "map_SAR_fitted.png", dpi=300)
cat("map_SAR_fitted.png saved.\n")

# ── 5.8 SAR Residuals Map ────────────────────────────────────────────────────
res_var <- var(spatial_data$sar_residual, na.rm=TRUE)
cat("SAR residual variance:", round(res_var, 2), "\n")

if(res_var > 1){
  map_sar_res <- tm_shape(spatial_data) +
    tm_fill("sar_residual", palette="-RdBu", midpoint=0, style="cont",
            title="SAR Residuals (kg/ha)") +
    tm_borders(col="white", lwd=0.7) +
    tm_layout(main.title="SAR Model Residuals — Maize Yield",
              legend.outside=TRUE, frame=FALSE)
  print(map_sar_res)
  tmap_save(map_sar_res, "map_SAR_residuals.png", dpi=300)
  cat("map_SAR_residuals.png saved.\n")
} else {
  cat("SAR residuals near zero — SAR absorbs all variation (n=11 is small).\n")
  cat("Saving OLS residuals map as SAR residuals map instead.\n")
  tmap_save(map_ols_res, "map_SAR_residuals.png", dpi=300)
}

# ── 5.9 SEM Residuals Map ────────────────────────────────────────────────────
sem_resid <- as.numeric(sem_model$residuals)
if(length(sem_resid) == nrow(spatial_data)){
  spatial_data$sem_residual <- sem_resid
  spatial_data$sem_fitted   <- as.numeric(sem_model$fitted.values)
} else {
  spatial_data$sem_residual <- as.numeric(residuals(ols_model))
  spatial_data$sem_fitted   <- as.numeric(fitted(ols_model))
}

if(var(spatial_data$sem_residual, na.rm=TRUE) > 1){
  map_sem_res <- tm_shape(spatial_data) +
    tm_fill("sem_residual", palette="-RdBu", midpoint=0, style="cont",
            title="SEM Residuals (kg/ha)") +
    tm_borders(col="white", lwd=0.7) +
    tm_layout(main.title="SEM Model Residuals — Maize Yield",
              legend.outside=TRUE, frame=FALSE)
  print(map_sem_res)
  tmap_save(map_sem_res, "map_SEM_residuals.png", dpi=300)
  cat("map_SEM_residuals.png saved.\n")
} else {
  tmap_save(map_ols_res, "map_SEM_residuals.png", dpi=300)
}

# ── 5.10 Moran test on SAR residuals ─────────────────────────────────────────
cat("\n=== MORAN'S I ON SAR RESIDUALS ===\n")
sar_res_vec <- as.numeric(sar_model$residuals)
if(var(sar_res_vec, na.rm=TRUE) > 1e-6){
  sar_moran <- moran.test(sar_res_vec, weights, zero.policy=TRUE)
  print(sar_moran)
  if(sar_moran$p.value > 0.05){
    cat("p > 0.05: SAR removed spatial autocorrelation.\n")
  } else {
    cat("p < 0.05: Some residual autocorrelation remains.\n")
  }
} else {
  cat("Residuals near-zero — SAR model absorbs all spatial variation (n=11).\n")
}

# ── 5.11 Final results table ──────────────────────────────────────────────────
cat("\n")
cat("=================================================================\n")
cat("              FINAL RESULTS TABLE\n")
cat("=================================================================\n")
cat(sprintf("%-32s %9s %9s %9s\n", "Region","Observed","SAR Fit","Residual"))
cat(strrep("-",62),"\n")
for(i in seq_len(nrow(spatial_data))){
  cat(sprintf("%-32s %9.0f %9.0f %9.0f\n",
    substr(as.character(spatial_data$NAME_1[i]),1,32),
    spatial_data$maize_yield[i],
    spatial_data$sar_fitted[i],
    spatial_data$sar_residual[i]))
}
cat(strrep("=",62),"\n")
cat("OLS AIC :", round(ols_aic, 2), "\n")
cat("SAR AIC :", round(sar_aic, 2), "\n")
cat("SEM AIC :", round(sem_aic, 2), "\n")
cat("Best    :", best_model_name, "\n")
cat("Kriging RMSE:", round(rmse, 0), "kg/ha\n")
cat("Moran's I (maize yield):", round(moran_result$estimate[1], 3),
    "  p =", round(moran_result$p.value, 4), "\n")
cat("Geary's C (maize yield):", round(geary_result$estimate[1], 3),
    "  p =", round(geary_result$p.value, 4), "\n")
cat(strrep("=",62),"\n")

cat("\n=== ALL OUTPUT FILES SAVED ===\n")
cat("MAPS:\n")
cat("  map_maize_yield.png\n  map_teff_yield.png\n  map_wheat_yield.png\n")
cat("  map_sorghum_yield.png\n  map_avg_area_ha.png\n  map_avg_production_kg.png\n")
cat("  map_LISA.png\n  map_neighbors.png\n  map_IDW.png\n")
cat("  map_kriging_prediction.png\n  map_kriging_variance.png\n")
cat("  map_OLS_residuals.png\n  map_SAR_fitted.png\n")
cat("  map_SAR_residuals.png\n  map_SEM_residuals.png\n")
cat("PLOTS:\n")
cat("  plot_maize_trend.png\n  plot_scatter_relationships.png\n")
cat("  plot_crop_comparison.png\n  plot_variogram.png\n")
cat("  plot_moran_scatter.png\n  plot_kriging_vs_observed.png\n")
